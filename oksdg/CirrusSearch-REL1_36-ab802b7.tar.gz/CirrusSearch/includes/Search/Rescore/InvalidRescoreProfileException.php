<?php

namespace CirrusSearch\Search\Rescore;

/**
 * Exception thrown if an error has been detected in the rescore profiles
 */
class InvalidRescoreProfileException extends \Exception {
}
