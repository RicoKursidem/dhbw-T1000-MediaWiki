'use strict';

( function ( $ ) {
	const a = $( '<h3>Correlatos</h3>' );
	// eslint-disable-next-line no-self-compare
	if ( a === a ) {
		console.log( a );
	}
}() );
