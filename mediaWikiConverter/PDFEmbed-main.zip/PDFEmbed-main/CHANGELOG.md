#v2.0.2
* Updated extension.json to support MediaWiki 1.30+.

#v2.0.1
* Switched over to iframes to support newer browsers.

#v2.0.0
* Converted to extension registration.
* Forcing a max-width: 100%; on the object container.

#v1.1.2
* Added page parameter.

#v1.1.1
* German Translations provided by kghbln <kontakt@wikihoster.net>

#v1.1
* Fix PHP notices being thrown for some parameters.
* Missing language string.